git add README.md
git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/fabianvcpz/fabiangallardo.github.io.git
git push -u origin main

